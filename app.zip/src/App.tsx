import { useState, FormEvent, ChangeEvent, useEffect } from "react";
import {
  UploadCloud, CheckCircle, MapPin, Building,
  CreditCard, User, Calendar, ShieldCheck, Zap
} from "lucide-react";
import { motion } from "motion/react";

type FileData = { file: File | null; base64: string; name: string } | null;
interface OdooOpcion { id: string | number; nombre: string; }

export default function App() {
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState({ type: "", msg: "" });

  const [formData, setFormData] = useState({
    clienteNombre: "",
    correoCliente: "",
    telefono: "",
    tipoCliente: "",
    numeroCedula: "",
    fechaNacimiento: "",
    callePrincipal: "",
    calleSecundaria: "",
    formaPago: "",
    sucursal: "",
    agenteId: "",
    canalVerificacion: "Correo Electrónico",
    estadoId: "",
    distritoId: "",
    localidadId: "",
    barrioId: "",
    packLeasing: "",
    modelo: "",
    color: "",
    operador: "",
    fechaPago: ""
  });

  const [isSuccess, setIsSuccess] = useState(false);

  const [options, setOptions] = useState({
    estados: [] as OdooOpcion[],
    distritos: [] as OdooOpcion[],
    localidades: [] as OdooOpcion[],
    barrios: [] as OdooOpcion[],
    tipoCliente: [] as OdooOpcion[],
    formaPago: [] as OdooOpcion[],
    sucursal: [] as OdooOpcion[],
    agentes: [] as OdooOpcion[],
    packLeasing: [] as OdooOpcion[],
    modelos: [] as OdooOpcion[],
    colores: [] as OdooOpcion[],
    operador: [] as OdooOpcion[],
    fechaPago: [] as OdooOpcion[]
  });

  const [modeloFieldMap, setmodeloFieldMap] = useState("");
  const [colorFieldMap, setColorFieldMap] = useState("");

  const [optionsLoading, setOptionsLoading] = useState(true);

  const [files, setFiles] = useState<{
    cedulaFrente: FileData;
    cedulaReverso: FileData;
    ingresos: FileData;
  }>({ cedulaFrente: null, cedulaReverso: null, ingresos: null });

  useEffect(() => {
    cargarOpcionesIniciales();
  }, []);

  const cargarOpcionesIniciales = async () => {
    setOptionsLoading(true);
    try {
      await Promise.all([
        fetch("/api/odoo/opciones?campo=x_studio_tipo_de_cliente").then(r => r.json()),
        fetch("/api/odoo/opciones?campo=x_studio_forma_de_pago").then(r => r.json()),
        fetch("/api/odoo/opciones?campo=x_studio_sucursale_de_venta_1").then(r => r.json()),
        fetch("/api/odoo/agentes").then(r => r.json()),
        fetch("/api/odoo/geografia/res.country.state").then(r => r.json()),
        fetch("/api/odoo/opciones?campo=x_studio_pack_de_leasing").then(r => r.json()),
        fetch("/api/odoo/opciones?campo=x_studio_operador_de_lina").then(r => r.json()),
        fetch("/api/odoo/opciones?campo=x_studio_fecha_de_pago").then(r => r.json())
      ])
        .then(([tipoC, formaP, suc, agentes, est, pack, oper, fecha]) => {
          setOptions(prev => ({
            ...prev,
            tipoCliente: tipoC.opciones || [],
            formaPago: formaP.opciones || [],
            sucursal: suc.opciones || [],
            agentes: agentes.opciones || [],
            estados: est.opciones || [],
            packLeasing: pack.opciones || [],
            operador: oper.opciones || [],
            fechaPago: fecha.opciones || []
          }));
        });
    } catch (e) {
      console.error("Error al cargar opciones iniciales:", e);
    } finally {
      setOptionsLoading(false);
    }
  };

  useEffect(() => {
    if (!formData.estadoId) return;
    setOptions(prev => ({ ...prev, distritos: [], localidades: [], barrios: [] }));
    setFormData(prev => ({ ...prev, distritoId: "", localidadId: "", barrioId: "" }));
    fetch(`/api/odoo/geografia/res.district?filtro_campo=state_id&filtro_valor=${formData.estadoId}`)
      .then(r => r.json())
      .then(data => setOptions(prev => ({ ...prev, distritos: data.opciones || [] })));
  }, [formData.estadoId]);

  useEffect(() => {
    if (!formData.distritoId) return;
    setOptions(prev => ({ ...prev, localidades: [], barrios: [] }));
    setFormData(prev => ({ ...prev, localidadId: "", barrioId: "" }));
    fetch(`/api/odoo/geografia/res.location?filtro_campo=district_id&filtro_valor=${formData.distritoId}`)
      .then(r => r.json())
      .then(data => setOptions(prev => ({ ...prev, localidades: data.opciones || [] })));
  }, [formData.distritoId]);

  useEffect(() => {
    if (!formData.localidadId) return;
    setOptions(prev => ({ ...prev, barrios: [] }));
    setFormData(prev => ({ ...prev, barrioId: "" }));
    fetch(`/api/odoo/geografia/res.neighborhood?filtro_campo=location_id&filtro_valor=${formData.localidadId}`)
      .then(r => r.json())
      .then(data => setOptions(prev => ({ ...prev, barrios: data.opciones || [] })));
  }, [formData.localidadId]);

  // Lógica Árbol Leasing (Pack -> Modelo)
  useEffect(() => {
    setOptions(prev => ({ ...prev, modelos: [], colores: [] }));
    setFormData(prev => ({ ...prev, modelo: "", color: "" }));
    setmodeloFieldMap("");

    const pack = options.packLeasing.find((p: any) => p.id === formData.packLeasing)?.nombre || "";

    if (pack.includes("1")) {
      setmodeloFieldMap("x_studio_telefonos_pack_1");
      fetch(`/api/odoo/opciones?campo=x_studio_telefonos_pack_1`).then(r => r.json())
        .then(data => setOptions(prev => ({ ...prev, modelos: data.opciones || [] })));
    } else if (pack.includes("2 Pro")) {
      setOptions(prev => ({ ...prev, modelos: [{ id: "p1_pro", nombre: "P1 Pro" }] }));
    } else if (pack.includes("2")) {
      setmodeloFieldMap("x_studio_telefonos_pack_2");
      fetch(`/api/odoo/opciones?campo=x_studio_telefonos_pack_2`).then(r => r.json())
        .then(data => setOptions(prev => ({ ...prev, modelos: data.opciones || [] })));
    } else if (pack.includes("3")) {
      setmodeloFieldMap("x_studio_telefonos_pack_3");
      fetch(`/api/odoo/opciones?campo=x_studio_telefonos_pack_3`).then(r => r.json())
        .then(data => setOptions(prev => ({ ...prev, modelos: data.opciones || [] })));
    } else if (pack.toLowerCase().includes("tablet")) {
      setOptions(prev => ({ ...prev, modelos: [{ id: "ot6_kids", nombre: "OT6 Kids" }] }));
    }
  }, [formData.packLeasing, options.packLeasing]);

  // Lógica Árbol Leasing (Modelo -> Color)
  useEffect(() => {
    setOptions(prev => ({ ...prev, colores: [] }));
    setFormData(prev => ({ ...prev, color: "" }));
    setColorFieldMap("");

    const mod = options.modelos.find((t: any) => t.id === formData.modelo)?.nombre || formData.modelo;
    if (!mod) return;

    let field = "";
    if (mod.includes("C3")) field = "x_studio_color_del_telefono";
    else if (mod.includes("C61")) field = "x_studio_selection_field_97d_1jeshelms";
    else if (mod.includes("C60")) field = "x_studio_color_c60";
    else if (mod.includes("G5")) field = "x_studio_color_g5";
    else if (mod.includes("C65")) field = "x_studio_color_c65";
    else if (mod.includes("P1 Pro")) field = "x_studio_color_p1_pro";
    else if (mod.includes("P1")) field = "x_studio_color_p1";
    else if (mod.includes("WP100")) field = "x_studio_color_wp100_titan";
    else if (mod.includes("WP300")) field = "x_studio_color_wp300";
    else if (mod.includes("WP55")) field = "x_studio_color_wp55_ultra";
    else if (mod.includes("OT6")) field = "x_studio_color_de_g5_1";

    if (field) {
      setColorFieldMap(field);
      fetch(`/api/odoo/opciones?campo=${field}`).then(r => r.json())
        .then(data => setOptions(prev => ({ ...prev, colores: data.opciones || [] })));
    }
  }, [formData.modelo, options.modelos]);

  const toBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
  });

  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>, key: keyof typeof files) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      alert("El archivo es demasiado pesado (Máx 5MB)");
      e.target.value = "";
      return;
    }
    const base64 = await toBase64(file);
    setFiles(prev => ({ ...prev, [key]: { file, base64, name: file.name } }));
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setStatus({ type: "", msg: "" });

    try {
      const payload = {
        clienteNombre: formData.clienteNombre,
        correoCliente: formData.correoCliente,
        telefono: formData.telefono,
        tipoCliente: formData.tipoCliente,
        numeroCedula: formData.numeroCedula,
        fechaNacimiento: formData.fechaNacimiento,
        callePrincipal: formData.callePrincipal,
        calleSecundaria: formData.calleSecundaria,
        formaPago: formData.formaPago,
        sucursal: formData.sucursal || false,
        agenteId: formData.agenteId || null,
        estadoId: formData.estadoId || null,
        distritoId: formData.distritoId || null,
        localidadId: formData.localidadId || null,
        barrioId: formData.barrioId || null,
        packLeasing: formData.packLeasing || false,
        modeloField: modeloFieldMap,
        telefonoValue: formData.modelo || false,
        colorField: colorFieldMap,
        colorValue: formData.color || false,
        operador: formData.operador || false,
        fechaPago: formData.fechaPago || false,
        fileCedulaFrente: files.cedulaFrente
          ? { base64: files.cedulaFrente.base64, name: files.cedulaFrente.name } : null,
        fileCedulaReverso: files.cedulaReverso
          ? { base64: files.cedulaReverso.base64, name: files.cedulaReverso.name } : null,
        fileIngresos: files.ingresos
          ? { base64: files.ingresos.base64, name: files.ingresos.name } : null,
        canalVerificacion: formData.canalVerificacion,
      };

      // 1. Enviar a Odoo (backend local)
      const response = await fetch("/api/leasing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errJson = await response.json();
        throw new Error(errJson.error || "Error en el servidor de Odoo");
      }

      // El webhook de n8n ahora se dispara de forma segura desde el backend (server.ts) para evitar errores de CORS.
      setIsSuccess(true);
    } catch (err: any) {
      setStatus({ type: "error", msg: err.message || "Hubo un error al procesar tu solicitud." });
    } finally {
      setLoading(false);
    }
  };

  const selectClass = "w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 appearance-none cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed";

  return (
    <div className="bg-[#F8FAFC] font-sans text-slate-900 flex flex-col min-h-screen">
      <div className="fixed top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 z-50"></div>

      <nav className="sticky top-0 bg-white/80 backdrop-blur-md border-b border-slate-200 px-8 py-4 flex justify-between items-center z-40">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-200">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <span className="font-extrabold text-2xl tracking-tight text-slate-800">
            Leasing <span className="text-indigo-600">Odoo</span>
          </span>
        </div>
        <div className="hidden md:flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-full text-xs text-slate-600 font-semibold">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
          Odoo 18 Ready
        </div>
      </nav>

      <main className="flex-1 p-4 md:p-12 flex flex-col xl:flex-row gap-12 max-w-[1500px] mx-auto w-full">

        <div className="w-full xl:w-[400px] flex flex-col gap-8">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
            <h1 className="text-4xl md:text-5xl font-black text-slate-900 leading-tight">
              Solicitud de <span className="text-indigo-600">Leasing</span>
            </h1>
            <p className="text-slate-500 text-lg">
              Sincroniza tus datos directamente con el módulo de Aprobaciones de Odoo.
            </p>
          </motion.div>

          <div className="bg-white rounded-3xl p-8 shadow-xl shadow-slate-200/50 border border-slate-100">
            <h2 className="text-xl font-bold mb-6 text-slate-800 flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-indigo-600" />
              Verificación SIFEN
            </h2>
            <div className="space-y-6">
              {[
                { step: 1, title: "Identidad", desc: "Validación de CI y datos personales." },
                { step: 2, title: "Ubicación", desc: "Geolocalización para facturación." },
                { step: 3, title: "Análisis", desc: "Procesamiento en Odoo Approvals." }
              ].map((s, i) => (
                <div key={i} className="flex gap-4 items-start">
                  <div className="w-8 h-8 rounded-full bg-slate-50 border border-slate-100 text-slate-400 flex items-center justify-center text-sm font-bold flex-shrink-0">{s.step}</div>
                  <div>
                    <p className="text-sm font-bold text-slate-800">{s.title}</p>
                    <p className="text-xs text-slate-500">{s.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex-1 bg-white rounded-[2.5rem] shadow-xl border border-slate-200/50 overflow-hidden">

          {isSuccess ? (
            <div className="p-16 text-center space-y-6 flex flex-col items-center justify-center min-h-[500px]">
              <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mb-6">
                <CheckCircle className="w-12 h-12 text-green-600" />
              </div>
              <h2 className="text-3xl font-black text-slate-800 tracking-tight">¡Solicitud enviada con éxito!</h2>
              <p className="text-slate-500 text-lg max-w-md mx-auto leading-relaxed">
                Para continuar con la aprobación, te acabamos de enviar un enlace seguro a tu <span className="font-bold text-indigo-600">{formData.canalVerificacion}</span>. Por favor, ábrelo para realizar la validación de identidad con Didit.
              </p>
              <button onClick={() => window.location.reload()} className="mt-8 px-8 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-all">
                Cargar nueva solicitud
              </button>
            </div>
          ) : (
            <>
              <div className="px-10 py-8 border-b border-slate-100 bg-slate-50/40">
                <h2 className="text-2xl font-black text-slate-800 tracking-tight">Nuevo Formulario de Registro</h2>
              </div>

              <form onSubmit={handleSubmit} className="p-10 space-y-8">
                <div className="grid grid-cols-2 gap-x-10 gap-y-6">

                  <div className="col-span-2 md:col-span-1 space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Nombre Completo *</label>
                    <div className="relative">
                      <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input required type="text" placeholder="Juan Pérez"
                        className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all"
                        value={formData.clienteNombre}
                        onChange={e => setFormData({ ...formData, clienteNombre: e.target.value })} />
                    </div>
                  </div>

                  <div className="col-span-2 md:col-span-1 space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Correo Electrónico *</label>
                    <div className="relative">
                      <div className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 font-bold">@</div>
                      <input required type="email" placeholder="ejemplo@correo.com"
                        title="Ingresa un correo válido (ej: usuario@gmail.com)"
                        className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all"
                        value={formData.correoCliente}
                        onChange={e => setFormData({ ...formData, correoCliente: e.target.value })} />
                    </div>
                  </div>

                  <div className="col-span-2 md:col-span-1 space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Teléfono *</label>
                    <div className="relative">
                      <div className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 font-bold">#</div>
                      <input required type="tel" placeholder="09XX XXX XXX"
                        pattern="^09[0-9]{8}$"
                        title="Formato de Paraguay: debe empezar con 09 y tener 10 dígitos numéricos en total."
                        className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all"
                        value={formData.telefono}
                        onChange={e => setFormData({ ...formData, telefono: e.target.value })} />
                    </div>
                  </div>

                  <div className="col-span-2 md:col-span-1 space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Número de Cédula *</label>
                    <div className="relative">
                      <CreditCard className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input required type="text" placeholder="1234567"
                        pattern="^[0-9.]{5,15}$"
                        title="Ingresa un número de cédula válido (solo números y puntos opcionales)."
                        className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all"
                        value={formData.numeroCedula}
                        onChange={e => setFormData({ ...formData, numeroCedula: e.target.value })} />
                    </div>
                  </div>

                  <div className="col-span-2 space-y-4 pt-4">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Canal de Verificación de Identidad *</label>
                    <div className="flex gap-6">
                      <label className="flex items-center gap-3 cursor-pointer">
                        <div className="relative flex items-center justify-center">
                          <input type="radio" name="canalVerificacion" value="Correo Electrónico"
                            className="peer sr-only"
                            checked={formData.canalVerificacion === "Correo Electrónico"}
                            onChange={e => setFormData({ ...formData, canalVerificacion: e.target.value })} />
                          <div className="w-5 h-5 border-2 border-slate-300 rounded-full peer-checked:border-indigo-600 peer-checked:bg-indigo-600 transition-all"></div>
                          <div className="absolute w-2 h-2 bg-white rounded-full opacity-0 peer-checked:opacity-100 transition-all"></div>
                        </div>
                        <span className="text-sm font-semibold text-slate-700">Correo Electrónico</span>
                      </label>
                      <label className="flex items-center gap-3 cursor-pointer">
                        <div className="relative flex items-center justify-center">
                          <input type="radio" name="canalVerificacion" value="Teléfono"
                            className="peer sr-only"
                            checked={formData.canalVerificacion === "Teléfono"}
                            onChange={e => setFormData({ ...formData, canalVerificacion: e.target.value })} />
                          <div className="w-5 h-5 border-2 border-slate-300 rounded-full peer-checked:border-indigo-600 peer-checked:bg-indigo-600 transition-all"></div>
                          <div className="absolute w-2 h-2 bg-white rounded-full opacity-0 peer-checked:opacity-100 transition-all"></div>
                        </div>
                        <span className="text-sm font-semibold text-slate-700">Teléfono (WhatsApp/SMS)</span>
                      </label>
                    </div>
                  </div>

                  <div className="col-span-2 md:col-span-1 space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Tipo Cliente *</label>
                    <select required className={selectClass}
                      value={formData.tipoCliente}
                      onChange={e => setFormData({ ...formData, tipoCliente: e.target.value })}>
                      <option value="">{optionsLoading ? "Cargando..." : "Seleccione..."}</option>
                      {options.tipoCliente.map(o => <option key={o.id} value={o.id}>{o.nombre}</option>)}
                    </select>
                  </div>

                  <div className="col-span-2 md:col-span-1 space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Fecha Nacimiento *</label>
                    <div className="relative">
                      <Calendar className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input required type="date"
                        className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all"
                        value={formData.fechaNacimiento}
                        onChange={e => setFormData({ ...formData, fechaNacimiento: e.target.value })} />
                    </div>
                  </div>

                  <div className="col-span-2 bg-indigo-50/30 p-8 rounded-[2rem] border border-indigo-100/50 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Departamento *</label>
                      <select required className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs font-bold outline-none focus:ring-2 focus:ring-indigo-400"
                        value={formData.estadoId}
                        onChange={e => setFormData({ ...formData, estadoId: e.target.value })}>
                        <option value="">{optionsLoading ? "Cargando..." : "Seleccione..."}</option>
                        {options.estados.map(o => <option key={o.id} value={o.id}>{o.nombre}</option>)}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Distrito *</label>
                      <select required disabled={!formData.estadoId || options.distritos.length === 0}
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs font-bold disabled:opacity-50 outline-none"
                        value={formData.distritoId}
                        onChange={e => setFormData({ ...formData, distritoId: e.target.value })}>
                        <option value="">{!formData.estadoId ? "Primero dept." : "Seleccione..."}</option>
                        {options.distritos.map(o => <option key={o.id} value={o.id}>{o.nombre}</option>)}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Ciudad *</label>
                      <select required disabled={!formData.distritoId || options.localidades.length === 0}
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs font-bold disabled:opacity-50 outline-none"
                        value={formData.localidadId}
                        onChange={e => setFormData({ ...formData, localidadId: e.target.value })}>
                        <option value="">{!formData.distritoId ? "Primero distrito." : "Seleccione..."}</option>
                        {options.localidades.map(o => <option key={o.id} value={o.id}>{o.nombre}</option>)}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Barrio *</label>
                      <select required disabled={!formData.localidadId || options.barrios.length === 0}
                        className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs font-bold disabled:opacity-50 outline-none"
                        value={formData.barrioId}
                        onChange={e => setFormData({ ...formData, barrioId: e.target.value })}>
                        <option value="">{!formData.localidadId ? "Primero ciudad." : "Seleccione..."}</option>
                        {options.barrios.map(o => <option key={o.id} value={o.id}>{o.nombre}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="col-span-2 md:col-span-1 space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Calle Principal *</label>
                    <div className="relative">
                      <MapPin className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input required type="text" placeholder="Ej: Avda. San Martín"
                        className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all"
                        value={formData.callePrincipal}
                        onChange={e => setFormData({ ...formData, callePrincipal: e.target.value })} />
                    </div>
                  </div>

                  <div className="col-span-2 md:col-span-1 space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Calle Secundaria *</label>
                    <input required type="text" placeholder="Ej: Esq. Las Magnolias"
                      className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all"
                      value={formData.calleSecundaria}
                      onChange={e => setFormData({ ...formData, calleSecundaria: e.target.value })} />
                  </div>

                  <div className="col-span-2 space-y-6 pt-6 border-t border-slate-100">
                    <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest">Información de Leasing</h3>
                    <div className="grid grid-cols-2 gap-x-10 gap-y-6">
                      <div className="col-span-2 md:col-span-1 space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Pack de Leasing *</label>
                        <select required value={formData.packLeasing} onChange={e => setFormData({ ...formData, packLeasing: e.target.value })}
                          className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all appearance-none font-medium">
                          <option value="">Seleccione Pack...</option>
                          {options.packLeasing.map((opt: any) => <option key={opt.id} value={opt.id}>{opt.nombre}</option>)}
                        </select>
                      </div>
                      <div className="col-span-2 md:col-span-1 space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Modelo *</label>
                        <select required disabled={!formData.packLeasing} value={formData.modelo} onChange={e => setFormData({ ...formData, modelo: e.target.value })}
                          className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all appearance-none font-medium disabled:opacity-50">
                          <option value="">{options.modelos.length === 0 ? "Primero elija un pack" : "Seleccione Modelo..."}</option>
                          {options.modelos.map((opt: any) => <option key={opt.id} value={opt.id}>{opt.nombre}</option>)}
                        </select>
                      </div>
                      <div className="col-span-2 md:col-span-1 space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Color *</label>
                        <select required disabled={!formData.modelo} value={formData.color} onChange={e => setFormData({ ...formData, color: e.target.value })}
                          className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all appearance-none font-medium disabled:opacity-50">
                          <option value="">{options.colores.length === 0 ? "Primero elija modelo" : "Seleccione Color..."}</option>
                          {options.colores.map((opt: any) => <option key={opt.id} value={opt.id}>{opt.nombre}</option>)}
                        </select>
                      </div>
                      <div className="col-span-2 md:col-span-1 space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Operador de Línea *</label>
                        <select required value={formData.operador} onChange={e => setFormData({ ...formData, operador: e.target.value })}
                          className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all appearance-none font-medium">
                          <option value="">Seleccione Operador...</option>
                          {options.operador.map((opt: any) => <option key={opt.id} value={opt.id}>{opt.nombre}</option>)}
                        </select>
                      </div>
                    </div>
                  </div>

                  <div className="col-span-2 space-y-6 pt-6 border-t border-slate-100">
                    <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest">Información de Pago</h3>
                    <div className="grid grid-cols-2 gap-x-10 gap-y-6">
                      <div className="col-span-2 md:col-span-1 space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Forma de Pago *</label>
                        <select required className={selectClass}
                          value={formData.formaPago}
                          onChange={e => setFormData({ ...formData, formaPago: e.target.value })}>
                          <option value="">{optionsLoading ? "Cargando..." : "Seleccione..."}</option>
                          {options.formaPago.map(o => <option key={o.id} value={o.id}>{o.nombre}</option>)}
                        </select>
                      </div>
                      <div className="col-span-2 md:col-span-1 space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Fecha de Pago *</label>
                        <select required value={formData.fechaPago} onChange={e => setFormData({ ...formData, fechaPago: e.target.value })}
                          className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all appearance-none font-medium">
                          <option value="">Seleccione Fecha...</option>
                          {options.fechaPago.map((opt: any) => <option key={opt.id} value={opt.id}>{opt.nombre}</option>)}
                        </select>
                      </div>
                    </div>
                  </div>

                  <div className="col-span-2 space-y-6 pt-6 border-t border-slate-100">
                    <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest">Información de Venta</h3>
                    <div className="grid grid-cols-2 gap-x-10 gap-y-6">
                      <div className="col-span-2 md:col-span-1 space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Agente de Venta *</label>
                        <select required className={selectClass}
                          value={formData.agenteId}
                          onChange={e => setFormData({ ...formData, agenteId: e.target.value })}>
                          <option value="">{optionsLoading ? "Cargando..." : "Seleccione Agente..."}</option>
                          {options.agentes.map(o => <option key={o.id} value={o.id}>{o.nombre}</option>)}
                        </select>
                      </div>
                      <div className="col-span-2 md:col-span-1 space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Sucursal *</label>
                        <select required className={selectClass}
                          value={formData.sucursal}
                          onChange={e => setFormData({ ...formData, sucursal: e.target.value })}>
                          <option value="">{optionsLoading ? "Cargando..." : "Seleccione Sucursal..."}</option>
                          {options.sucursal.map(o => <option key={o.id} value={o.id}>{o.nombre}</option>)}
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Documentos */}
                  <div className="col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-6 pt-4">
                    {[
                      { key: 'cedulaFrente', label: 'C.I. Frente' },
                      { key: 'cedulaReverso', label: 'C.I. Reverso' },
                      { key: 'ingresos', label: 'Ingresos' }
                    ].map((doc) => {
                      const fileObj = files[doc.key as keyof typeof files];
                      return (
                        <div key={doc.key}
                          className={`relative border-2 border-dashed ${fileObj ? 'border-indigo-400 bg-indigo-50/30' : 'border-slate-200 bg-slate-50'} rounded-2xl p-6 text-center transition-all cursor-pointer`}>
                          <div className={`mb-2 p-2 rounded-full inline-block ${fileObj ? 'bg-indigo-600 text-white' : 'bg-white text-slate-400 shadow-sm'}`}>
                            {fileObj ? <CheckCircle className="w-5 h-5" /> : <UploadCloud className="w-5 h-5" />}
                          </div>
                          <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest truncate">
                            {fileObj ? (fileObj as any).name : doc.label}
                          </p>
                          <input
                            required={!fileObj}
                            type="file"
                            accept="image/*,application/pdf"
                            className="absolute inset-0 opacity-0 cursor-pointer"
                            onChange={e => handleFileChange(e, doc.key as any)} />
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Status */}
                {status.msg && (
                  <div className={`p-4 rounded-2xl text-sm font-bold text-center ${status.type === 'success' ? 'bg-green-50 text-green-700 border border-green-100' : 'bg-red-50 text-red-700 border border-red-100'}`}>
                    {status.msg}
                  </div>
                )}

                <button type="submit" disabled={loading || optionsLoading}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-black py-5 rounded-2xl shadow-xl transition-all active:scale-[0.98] flex items-center justify-center gap-3">
                  {loading ? "Procesando solicitud y verificación..." : optionsLoading ? "Cargando opciones..." : "Enviar Solicitud y Verificar"}
                </button>
              </form>
            </>
          )}

          <div className="px-10 py-6 bg-slate-50/80 border-t border-slate-100 flex justify-between items-center">
            <div className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest">
              <div className="w-2 h-2 rounded-full bg-green-500"></div>
              Odoo 18 XML-RPC API
            </div>
            <div className="bg-white p-2 rounded-lg border border-slate-100 shadow-sm">
              <Building className="w-5 h-5 text-indigo-600" />
            </div>
          </div>
        </motion.div>
      </main>

      <footer className="p-12 text-center text-[10px] text-slate-400 font-black uppercase tracking-[0.4em]">
        Portal de Leasing Institucional — Powered by Richford Paraguay S.A
      </footer>
    </div>
  );
}
